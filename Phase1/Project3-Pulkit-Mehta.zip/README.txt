# ENPM-661 Project 3
# Author: Pulkit Mehta (UID: 117551693) 

Github: https://github.com/pulkitmehta09/ENPM661-Project3.git

INSTRUCTIONS:

1. Download all the files into a folder.

// The functions.py file contains all the function definitions.

2. Open terminal and run the python file from the folder as:

```
$ python3 pulkit_mehta.py 
```

or run the file from any other IDE and follow the instructions on the terminal.

The generated video will be saved in the same folder containing all the above files.
